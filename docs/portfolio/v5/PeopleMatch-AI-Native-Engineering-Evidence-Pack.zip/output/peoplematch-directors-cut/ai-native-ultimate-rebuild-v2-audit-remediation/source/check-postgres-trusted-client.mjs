// Execute the actual V5 TypeScript trust validator against the disposable PostgreSQL API.
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';

const here = path.dirname(fileURLToPath(import.meta.url));
const audit = path.resolve(here, '..');
const repo = path.resolve(audit, '../../..');
const require = createRequire(import.meta.url);
const ts = require(path.join(repo, 'frontend/node_modules/typescript'));
const source = await readFile(path.join(audit, 'repro/local-v5-archive-snapshot/frontend/src/lib/requirement-review.ts'), 'utf8');
const compiled = ts.transpileModule(source, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
}).outputText;
const exports = {};
new Function('exports', compiled)(exports);

const base = 'http://127.0.0.1:8014';
process.env.NEXT_PUBLIC_API_BASE_URL = base;
const results = [];
for (const id of [4, 5]) {
  const response = await fetch(`${base}/api/v1/match-explanations/${id}/requirement-review`);
  if (response.status !== 200) throw new Error(`API ${id}: HTTP ${response.status}`);
  const envelope = await response.json();
  if (!exports.isRequirementReview(envelope.data)) throw new Error(`Trust validator rejected seeded PostgreSQL response ${id}`);
  const loaded = await exports.loadRequirementReview(id);
  if (loaded.source_explanation_id !== id) throw new Error('Explanation identity mismatch');
  const sourceRefs = loaded.source_descriptors.map(item => item.evidence_ref);
  const cited = [...loaded.requirements.flatMap(item => item.propositions), ...loaded.cross_requirement_propositions]
    .flatMap(item => item.evidence_refs).filter(ref => ref.startsWith('candidate:'));
  if (sourceRefs.length !== new Set(sourceRefs).size || sourceRefs.some(ref => !cited.includes(ref))
      || cited.some(ref => !sourceRefs.includes(ref))) throw new Error('Source closure mismatch');
  if (exports.isRequirementReview({ ...loaded, source_descriptors: [
    ...loaded.source_descriptors, { evidence_ref: `candidate:${loaded.result_rank}:skill:unlinked`, source_kind: 'historical_skill_claim', description: 'unlinked' },
  ] })) throw new Error('Extra source was accepted');
  if (exports.isRequirementReview({ ...loaded, source_descriptors: [] })) throw new Error('Missing sources were accepted');
  results.push({ id, status: response.status, trusted: true, candidateId: loaded.candidate_id,
    rank: loaded.result_rank, requirements: loaded.requirements.length, sources: sourceRefs.length });
}
await writeFile(path.join(audit, 'qa/postgres-v5-trusted-client.json'), JSON.stringify({
  fixture: 'independently seeded isolated PostgreSQL, deterministic mock provider; not historical Fresh Top-3',
  results, extraSourceRejected: true, missingSourceRejected: true,
}, null, 2));
console.log(`PASS: seeded PostgreSQL API → actual TypeScript trusted client ${results.length}/2; negative source checks reject`);
