import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { mkdir, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';

const here = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(here, '../../../..');
const require = createRequire(import.meta.url);
const { chromium } = require(path.join(repo, 'frontend/node_modules/playwright'));
const output = path.resolve(here, '../qa/postgres-browser');
const runId = '00000000-0000-0000-0000-000000000941';
await mkdir(output, { recursive: true });

const browser = await chromium.launch({ headless: true });
const findings = [];
try {
  for (const viewport of [{ name: 'desktop', width: 1440, height: 1000 }, { name: 'mobile', width: 390, height: 844 }]) {
    const page = await browser.newPage({ viewport, deviceScaleFactor: 1.5 });
    const errors = [];
    const api = [];
    page.on('pageerror', error => errors.push(error.message));
    page.on('response', response => { if (response.url().includes('/api/v1/')) api.push({ status: response.status(), path: new URL(response.url()).pathname }); });
    try {
      await page.goto(`http://127.0.0.1:3001/?runId=${runId}`);
      await page.getByRole('link', { name: '逐项核实岗位核心要求 →' }).waitFor({ timeout: 20000 });
      const candidates = page.locator('nav[aria-label="Top 候选人"] button');
      if (await candidates.count() !== 2) throw new Error('Expected exactly two persisted fixture candidates');
      for (const [index, explanationId] of [[0, 4], [1, 5]]) {
        await candidates.nth(index).click();
        await page.getByRole('link', { name: '逐项核实岗位核心要求 →' }).click();
        await page.getByRole('heading', { name: '逐项核实岗位核心要求。' }).waitFor({ timeout: 20000 });
        await page.getByText('核心要求', { exact: true }).waitFor({ timeout: 20000 });
        await page.getByText('查看来源元数据').first().click();
        const body = await page.locator('body').innerText();
        const geometry = await page.evaluate(() => ({ scrollWidth: document.documentElement.scrollWidth, clientWidth: document.documentElement.clientWidth }));
        if (!body.includes(`Explanation #${explanationId}`) || !body.includes('未知不等于缺少能力') || !body.includes('历史 Evidence Bundle') || geometry.scrollWidth > geometry.clientWidth + 1) {
          throw new Error(JSON.stringify({ viewport: viewport.name, explanationId, geometry, body: body.slice(0, 700) }));
        }
        if (index === 0) {
          await page.screenshot({ path: path.join(output, `${viewport.name}-requirement-review.png`), fullPage: true, animations: 'disabled' });
          await page.locator('section[aria-label="核心要求"]').scrollIntoViewIfNeeded();
          await page.screenshot({ path: path.join(output, `${viewport.name}-requirement-review-viewport.png`), animations: 'disabled' });
        }
        findings.push({ viewport: viewport.name, explanationId, requirementsVisible: true, sourceExpanded: true, noHorizontalOverflow: true, clientWidth: geometry.clientWidth, scrollWidth: geometry.scrollWidth });
        if (index === 0) {
          await page.goto(`http://127.0.0.1:3001/?runId=${runId}`);
          await page.getByRole('link', { name: '逐项核实岗位核心要求 →' }).waitFor({ timeout: 20000 });
        }
      }
      if (errors.length || api.some(item => item.status !== 200)) throw new Error(JSON.stringify({ errors, api }));
      findings.push({ viewport: viewport.name, pageErrors: errors, apiResponses: api, candidateSwitch: true });
    } finally {
      await page.close();
    }
  }
  await writeFile(path.join(output, 'result.json'), JSON.stringify({ runId, fixture: 'newly seeded isolated PostgreSQL synthetic fixture; not historical Qwen run', findings }, null, 2));
  process.stdout.write(JSON.stringify(findings, null, 2));
} finally {
  await browser.close();
}
