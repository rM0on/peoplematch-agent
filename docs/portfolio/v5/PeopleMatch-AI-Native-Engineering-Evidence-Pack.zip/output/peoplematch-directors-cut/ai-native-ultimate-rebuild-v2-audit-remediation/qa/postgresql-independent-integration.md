# Independently seeded PostgreSQL verification · 2026-10-18

**Result: PASS for an isolated, newly seeded synthetic fixture.** This is not the saved 2026-10-14 historical Fresh MatchRun readback, not a new Qwen call, and not a new ranking run.

## Isolation and environment correction

The first sandboxed Docker API call returned permission denied, and the host had no listener at 5432 in that context. A bounded allowed-context `docker info` returned Engine 29.5.2. The audit therefore created only Compose project `pm-v2-audit-20261018`, using `postgres:16-alpine`, database `peoplematch_audit_v2`, loopback `127.0.0.1:55439`, a tmpfs data directory, no named volume, and a synthetic local-only credential. `docker compose ps` reported a healthy container; SQL identity check returned the expected database/user and PostgreSQL 16.14. Existing PeopleMatch services on 5432 and their volumes were not targeted. The disposable database is **not** a production or historical database.

The exact service definition is `repro/postgres-audit.compose.yml`; `repro/check-isolated-postgres.py` refuses any other host, port, database or user for both `DATABASE_URL` and, when set, `TEST_DATABASE_URL`. A safety regression probe showed the initial guard accepted a mismatched `TEST_DATABASE_URL` (exit 0) without connecting to that wrong target; the corrected guard rejects it (exit 1) and accepts both values pointed to the audit DB (exit 0). Do not copy the audit credential into a published environment. PowerShell process environment provided both dedicated URLs to the isolated snapshot backend/tests. No `.env` was copied into the snapshot or ZIP.

## Executed gates

| Gate | Command / target | Current result | Evidence |
|---|---|---|---|
| Schema | `python -m alembic upgrade head` in isolated snapshot backend, after database identity check | Exit 0; migrations 0001–0006 | Execution record and isolated schema |
| Base persistence | `pytest tests/test_postgres_integration.py` | 12 passed, 0 skipped | `qa/postgres-base-junit.xml` |
| MatchRun/Explanation persistence | `pytest tests/test_match_run_postgres.py tests/test_explanation_postgres.py tests/test_explanation_generation_postgres.py` | 19 passed, 0 skipped | `qa/postgres-history-junit.xml` |
| Deterministic seed | Re-ran `test_postgres_generation_success_persists_grounded_outputs_and_bounded_attempt` from the existing mock-provider test | 1 passed; left one synthetic completed Run for readback | `qa/postgres-fixture-seed-junit.xml` |
| Typed GET readback | `repro/verify-v5-postgres-readback.py` with exact DB identity and backend `PYTHONPATH` | Two `200`, missing ID `404`; Pydantic contract and exact source closure; before/after persisted snapshot equal | `qa/postgres-v5-api-readback.json` |
| Actual frontend trust code | `node source/check-postgres-trusted-client.mjs` against live backend HTTP | Both responses accepted; injected extra and missing source rejected | `qa/postgres-v5-trusted-client.json` |
| Actual browser | `node source/run-postgres-browser.mjs` against production Next.js at 3001 and FastAPI at 8014 | Desktop 1440 and mobile 390; both candidates, requirements and source drill-down; all captured API responses 200, no JS errors or horizontal overflow | `qa/postgres-browser/result.json` and screenshots |
| Post-browser invariance | Re-ran the readback script after browser interactions | Exit 0; MatchRun/Explanation identities, order, raw scores, fingerprints and persisted source output fingerprints unchanged | Updated `qa/postgres-v5-api-readback.json` |

The seeded MatchRun is `00000000-0000-0000-0000-000000000941`; ExplanationRun is `10000000-0000-0000-0000-000000000941`. It has **two** candidates in order, raw LTR scores **0.39 / 0.38**, and one saved explanation per candidate. Each GET returned three requirements including two must-haves. The server descriptors exactly equal candidate evidence actually used in displayed propositions, with the correct result-rank scope; cross-requirement propositions stay separate. This verifies the V5 read-only projection on this fixture, not all possible historical runs.

After the final readback, the audit FastAPI and Next.js sessions were stopped. The exact `pm-v2-audit-20261018` PostgreSQL service was stopped, leaving its disposable tmpfs data unavailable; no named volume was removed. A subsequent `docker ps` still showed the pre-existing PeopleMatch 5432, backend/frontend, Redis and Qdrant containers running. The saved JUnit/JSON/browser artifacts, not the ephemeral database, are the durable proof.

One first command used the wrong relative path; one earlier TestClient attempt outside its lifecycle yielded a transient second-response 500. After correcting the harness to use a context manager, both responses returned 200. A Windows asyncio Proactor shutdown diagnostic appeared after a passing script exit; it did not affect the DB assertions or browser run. These are harness issues, not suppressed application failures.

## What remains outside this proof

The 2026-10-14 **historical persisted Fresh Run** 3/3 readback remains a separate saved historical verification. The current disposable fixture does not re-run real Qwen, Hybrid Retrieval, LambdaMART, frozen Phase 11 Test, or a clean public clone. It does not prove production reliability or public GitHub publication. The default Turbopack build in the junction-based isolated snapshot still fails; browser validation used a separately reported webpack production build.
