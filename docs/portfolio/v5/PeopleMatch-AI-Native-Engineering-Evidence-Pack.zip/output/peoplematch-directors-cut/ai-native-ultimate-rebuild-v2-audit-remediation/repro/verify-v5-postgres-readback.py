"""Read-only V5 API check against the disposable seeded PostgreSQL container.

The fixture is seeded by the existing deterministic mock-provider PostgreSQL test.
It is not the historical Fresh Top-3 or a current Qwen run.
"""

import asyncio
import json
import os
from pathlib import Path

from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlalchemy.engine import make_url
from sqlalchemy.ext.asyncio import create_async_engine
from sqlalchemy.pool import NullPool

from app.main import create_app
from app.schemas.requirement_review import RequirementReviewV1


EXPECTED_RUN = "00000000-0000-0000-0000-000000000941"
EXPECTED_EXPLANATION_RUN = "10000000-0000-0000-0000-000000000941"
OUT = Path(__file__).resolve().parents[1] / "qa" / "postgres-v5-api-readback.json"


def checked_url():
    url = make_url(os.environ["DATABASE_URL"])
    if (url.host, url.port, url.database, url.username) != (
        "127.0.0.1", 55439, "peoplematch_audit_v2", "audit_v2"
    ):
        raise SystemExit("Refusing non-audit database target")
    return url


async def snapshot():
    engine = create_async_engine(checked_url(), poolclass=NullPool)
    try:
        async with engine.connect() as connection:
            identity = (await connection.execute(text(
                "SELECT current_database(), current_user"
            ))).one()
            if tuple(identity) != ("peoplematch_audit_v2", "audit_v2"):
                raise AssertionError("database identity mismatch")
            run = (await connection.execute(text(
                "SELECT run_id, status, result_fingerprint FROM match_runs WHERE run_id=:run"
            ), {"run": EXPECTED_RUN})).one()
            results = (await connection.execute(text(
                "SELECT candidate_id, result_rank, ltr_score_raw FROM match_results "
                "WHERE run_id=:run ORDER BY result_rank"
            ), {"run": EXPECTED_RUN})).all()
            explanation = (await connection.execute(text(
                "SELECT explanation_run_id, status, explanation_count, evidence_bundle_fingerprint "
                "FROM explanation_runs WHERE explanation_run_id=:explanation"
            ), {"explanation": EXPECTED_EXPLANATION_RUN})).one()
            outputs = (await connection.execute(text(
                "SELECT id, candidate_id, result_rank, candidate_output_fingerprint "
                "FROM match_explanations WHERE explanation_run_id=:explanation ORDER BY result_rank"
            ), {"explanation": EXPECTED_EXPLANATION_RUN})).all()
        return {
            "run": list(run),
            "results": [list(row) for row in results],
            "explanation": list(explanation),
            "outputs": [list(row) for row in outputs],
        }
    finally:
        await engine.dispose()


def main() -> None:
    before = asyncio.run(snapshot())
    assert before["run"][1] == before["explanation"][1] == "COMPLETED"
    assert len(before["results"]) == len(before["outputs"]) == 2
    assert before["explanation"][2] == 2

    responses = []
    with TestClient(create_app(), raise_server_exceptions=False) as client:
        for output_id, candidate_id, rank, output_fingerprint in before["outputs"]:
            response = client.get(
                f"/api/v1/match-explanations/{output_id}/requirement-review"
            )
            assert response.status_code == 200, (output_id, response.status_code, response.text)
            body = response.json()
            assert body["success"] is True
            view = RequirementReviewV1.model_validate(body["data"])
            assert view.source_explanation_id == output_id
            assert view.match_run_id == before["run"][0]
            assert view.explanation_run_id == before["explanation"][0]
            assert view.candidate_id == candidate_id and view.result_rank == rank
            assert view.ranking_fingerprint == before["run"][2]
            assert view.source_output_fingerprint == output_fingerprint
            assert view.source_bundle_fingerprint == before["explanation"][3]
            assert view.requirements
            assert all(row.source_refs == (f"job_requirement:{row.requirement_id}",)
                       for row in view.requirements)
            descriptors = {item.evidence_ref for item in view.source_descriptors}
            used = {
                ref for proposition in (
                    [item for row in view.requirements for item in row.propositions]
                    + list(view.cross_requirement_propositions)
                ) for ref in proposition.evidence_refs if ref.startswith("candidate:")
            }
            assert descriptors == used, (descriptors, used)
            assert all(ref.startswith(f"candidate:{rank}:") for ref in descriptors)
            assert all(len(item.job_requirement_refs) > 1
                       for item in view.cross_requirement_propositions)
            responses.append({
                "status": response.status_code,
                "candidate_id": candidate_id,
                "result_rank": rank,
                "requirement_count": len(view.requirements),
                "must_have_count": sum(row.priority == "must_have" for row in view.requirements),
                "descriptor_count": len(descriptors),
                "aggregate_count": len(view.cross_requirement_propositions),
            })
        missing = client.get("/api/v1/match-explanations/999999/requirement-review")
        assert missing.status_code == 404

    after = asyncio.run(snapshot())
    assert before == after, "read-only API mutated persisted run, ranking, explanation or source identities"
    record = {
        "database": "peoplematch_audit_v2",
        "fixture": "existing deterministic mock-provider PostgreSQL test, newly seeded in isolated tmpfs",
        "not_historical_fresh_run": True,
        "run_id": before["run"][0],
        "ranking_fingerprint": before["run"][2],
        "candidate_order": [item[0] for item in before["results"]],
        "ltr_raw_scores": [item[2] for item in before["results"]],
        "explanation_run_id": before["explanation"][0],
        "responses": responses,
        "missing_id_status": missing.status_code,
        "before_after_equal": True,
    }
    OUT.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    print("PASS: isolated PostgreSQL → GET API → typed source closure; 2 candidates; unchanged persisted snapshots")


if __name__ == "__main__":
    main()
