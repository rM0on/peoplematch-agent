"""Fail closed unless DATABASE_URL points to this disposable audit database."""

import asyncio
import os

from sqlalchemy import text
from sqlalchemy.engine import make_url
from sqlalchemy.ext.asyncio import create_async_engine


async def main() -> None:
    expected = ("127.0.0.1", 55439, "peoplematch_audit_v2", "audit_v2")
    for setting in ("DATABASE_URL", "TEST_DATABASE_URL"):
        if setting in os.environ:
            value = make_url(os.environ[setting])
            if (value.host, value.port, value.database, value.username) != expected:
                raise SystemExit(f"Refusing non-audit {setting} target")
    url = make_url(os.environ["DATABASE_URL"])
    engine = create_async_engine(url, pool_pre_ping=True)
    try:
        async with engine.connect() as connection:
            database, user, port = (
                await connection.execute(
                    text("SELECT current_database(), current_user, inet_server_port()")
                )
            ).one()
        if (database, user, port) != ("peoplematch_audit_v2", "audit_v2", 5432):
            raise SystemExit("Connected database identity mismatch")
        print(f"AUDIT DB VERIFIED: database={database} user={user} server_port={port}")
    finally:
        await engine.dispose()


if __name__ == "__main__":
    asyncio.run(main())
