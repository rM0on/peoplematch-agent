# Actual-code independent review · closure

Independent read-only reviewer inspected the V5 service, schema, API and frontend. Previous V5 historical-label, wrong JD ref and aggregate fan-out fixes remain present. This task identified two further implementation gaps and one availability edge; all are backed by new RED tests rather than invented execution stories.

| Finding | Root cause | Regression | Fix | Status |
|---|---|---|---|---|
| Opaque candidate-source drill-down | UI received proposition refs but no readable historical source metadata | Backend descriptor/unknown-ref tests; frontend source text test | Candidate/rank-scoped descriptions from the exact saved Evidence Bundle; invented refs return 409 | CLOSED: backend 116, frontend 103, browser drill-down |
| Valid long historical project becomes 409 | Unbounded tech-list join exceeded 500-character response contract | Long-valid-tech-list RED | Deterministically bounded summary with count of omitted terms and skill tags | CLOSED: backend 116 |
| Same-route query can display previous Explanation | Component effect ran only at mount and retained old payload | React same-route navigation RED | URL hook + request-keyed state, cancellation and Suspense | CLOSED: frontend 103, typecheck/build |
| Historical source-closure integration | HTTP 200 contained uncited project-evidence descriptors; the client correctly rejected all three historical payloads | Unlinked-signal regression observed RED; actual TS validator rejected 3/3 | Service validates all refs against saved Evidence Bundle but emits only descriptors used by displayed propositions | CLOSED: backend 116; historical API 3/3, trusted client 3/3, browser 1440/390 |

The descriptor is frozen metadata, not original resume/project artifact text. A row with diagnostic `available` but no selected proposition still cannot expose an exact candidate source in this view. Do not describe it as opening original evidence. The service remains a read-only projection. The existing historical persisted Run snapshot was identical before and after GET; no new ranking run was performed.

Current-task verification: `backend/.venv/Scripts/python.exe -m pytest backend/tests/test_requirement_review_workbench.py backend/tests/test_recruiter_proposition_runtime.py backend/tests/test_explanation_evidence_engine.py -q` → **116 passed**. `npm test -- --run` → **103 passed** across 16 files; `npm run typecheck`, `npm run lint`, `npm run build` exited 0. The actual Next.js desktop/mobile historical PostgreSQL-backed browser flow passed with no page errors or 390px overflow. Docker-backed isolated database seeding remains separate and **NOT VERIFIED**.
