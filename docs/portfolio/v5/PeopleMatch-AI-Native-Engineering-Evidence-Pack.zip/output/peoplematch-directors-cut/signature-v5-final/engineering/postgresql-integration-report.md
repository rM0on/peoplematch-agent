# PostgreSQL historical readback · 2026-10-14

Status: **VERIFIED for the existing persisted synthetic Fresh Run; NOT VERIFIED for an independently seeded PostgreSQL test database.** Docker Desktop Linux Engine remained inaccessible, but a local PeopleMatch PostgreSQL listener at `127.0.0.1:5432` was reachable. No Qwen call, new MatchRun, migration, seed, or database write was made.

## Persisted identity and scope

- MatchRun `22326fc2-1766-4c3c-a8f0-2cc81f70849c` and ExplanationRun `bb430ab9-3a9e-46a1-81e8-693b0aa1cfb4` were `COMPLETED`.
- Explanation IDs 141/142/143 correspond to `cand_019`, `cand_033`, `cand_006` in ranks 1/2/3. Stored LTR raw scores were `0.1804529604473291`, `-0.009822234421413912`, `-0.020959543807350902`. These are raw ranking scores, not probabilities.
- `engineering/probe_postgres_readonly.py` inspected stored rows; `engineering/readback_requirement_api.py` used real SQLAlchemy/asyncpg rows and the actual FastAPI GET handler. All 3 GETs returned 200, six requirements each, matching candidate/run/rank/fingerprint; source-descriptor counts were 3/3/2. The script compared persisted MatchRun, MatchResult, ExplanationRun and MatchExplanation snapshots before and after: **unchanged**.
- `engineering/serve_postgres_readonly.py` served the real API via connections with `default_transaction_read_only=on`, restricted to GET/HEAD/OPTIONS. POST returned 405. The browser route used this API, not the synthetic HTTP demo.

## Integration failure and repair

Before repair, the three historical GET responses were HTTP 200 but the actual frontend `isRequirementReview` validator rejected them. The service included four `project_evidence` source descriptors per candidate that no displayed single- or cross-requirement proposition cited. This violated the client's minimal source-closure contract. The client rejection was correct; relaxing it would hide a server projection defect.

The new `test_unlinked_historical_signal_does_not_leak_an_uncited_source_descriptor` observed **RED** with an extra `candidate:1:project_evidence:evidence_001`. The focused service change still validates every candidate reference against the saved Evidence Bundle, but adds a descriptor to the output set only when that proposition has requirement references and is actually displayed. The test then passed **GREEN**. Existing wrong-candidate, wrong-Explanation/Run, wrong fingerprint, missing source, duplicate requirement, aggregate attribution and mutable-profile tests remain in the 116-test related regression run.

`source/diagnose-postgres-response.mjs` executed the real frontend validator against all 3 persisted API payloads: `valid:true`, zero uncatalogued citations, zero uncited descriptors, and matching fingerprints. The real Next.js page then rendered Recruiter View → Requirement Review → expanded historical source → second candidate at both 1440px and 390px; there were no page errors or horizontal overflow. Screenshots are `pages/requirement-review-postgres-*`.

The browser probe was rerun after replacing a fixed 1.5-second wait with a wait for the actual `核心要求` content. One intermediate probe had timed out while the API calls returned 200 and the page was still loading; the condition-based rerun passed at both viewport sizes. This was a probe-timing correction, not an application-code change.

This establishes a read-only historical persisted synthetic Run projection through database → API → client contract → browser. It does **not** establish a fresh Provider or ranking run, production stability, or an independently seeded test-database integration.
