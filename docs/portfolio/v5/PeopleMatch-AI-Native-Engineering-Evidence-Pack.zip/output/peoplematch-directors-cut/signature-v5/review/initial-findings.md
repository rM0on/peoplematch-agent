# V5 independent code review — actual findings, 2026-10-13

Scope: the new read-only Requirement Review Workbench, not frozen PeopleMatch runtime. A separate read-only reviewer inspected source, tests and the first actual browser capture. The reviewer did not edit files or run Provider/database writes.

| Severity | Finding | First-state evidence / risk | Required disposition |
|---|---|---|---|
| P1 | Candidate source labels used mutable current Candidate project names | Initial `evidenceLabel` used `run.candidates[...].projects` and `.project_evidence` to label historical refs. Candidate PATCH can later change names/statements without changing the Explanation fingerprint. | Do not relabel historical refs from current profile. Show immutable canonical source ID or snapshot-backed text. |
| P1 | Synthesized JD reference was not checked against stored evidence ID | `RequirementReviewService` constructed `job_requirement:{requirement_id}` while historical schema also stores `evidence_id` independently. | Reject a canonical bundle where those disagree. |
| P1 | Multi-requirement proposition fanned out as if per-row proof | Initial service appended a proposition to every JD ref. In first browser screenshot, broad recommendation appeared in several rows. | Keep multi-requirement recommendations aggregate, never as one requirement's evidence. |
| P2 | Requested explanation ID not bound on frontend response | Loader validated shape and run ownership but could accept a different explanation from the same run. | Bind returned ID to requested ID. |
| P2 | Frontend proposition type guard accepted arbitrary semantic enum strings | Shape guard checked only `typeof` for kind/predicate/subject/modality. | Mirror the closed semantic policy for the new endpoint. |
| P2 | API test accepted either 404 or 409 | A supposed missing test actually exercised ID mismatch. | Separate exact missing and mismatched tests and assert typed errors. |
| P2 | Wording claimed original JD order | Historical Evidence Bundle builder sorts requirements by ID. | Claim canonical persisted bundle order only. |
| P2 | `available` diagnostic could coexist with zero selected propositions | Diagnostic and selected explanation are distinct coverage scopes. | Explicitly explain both axes; avoid “no material association” claim. |

The review also identified a portfolio-claim risk: an early V5 page draft described a source-mixing scenario as a recorded historical incident. The final editorial page must tie its wording to the actual V5 reviewer finding and actual RED/GREEN regression, not suggest a missing original Codex conversation.
