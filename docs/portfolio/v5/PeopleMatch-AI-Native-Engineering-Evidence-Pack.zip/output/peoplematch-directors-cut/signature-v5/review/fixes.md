# Review resolution — observed changes

1. Added a backend adversarial test that changes a stored `evidence_id` without changing the requirement ID. It failed before the service check; `RequirementReviewService.get` now rejects the mismatch. Exact 404 and 409 API paths are separately asserted.
2. Multi-ref propositions now populate `cross_requirement_propositions` rather than each row. Single-ref propositions alone appear as row-specific. The frontend states that aggregate suggestions do not prove an individual requirement.
3. Replaced current Candidate project-name/statement labels with the canonical historical candidate source ID. The current profile name is explicitly marked display-only. A frontend regression uses mutable `RAG Demo` and expects only `candidate:1:project:p1` as the source label; the new expectation failed on the old renderer, then passed after the fix.
4. Added requested Explanation ID binding in the frontend loader. A mock response from another explanation in the same run was observed to resolve before the fix and reject after it.
5. Strengthened the new endpoint's frontend validator with closed kind/predicate/subject/modality/polarity/allowed-field rules and exact single-vs-multi-ref shape checks. Added malformed-kind rejection.
6. Updated the acceptance contract from “original JD order” to “canonical persisted bundle order” and UI copy so diagnostic availability is not confused with the selected explanation.
7. Added a foreign candidate-rank reference adversarial test. This checks the existing fail-closed rank guard without changing frozen Grounding or Proposition semantics.

These changes are additive to the new V5 feature only. No frozen ranking, Provider, evaluation or historical artifact was modified. The reviewer report is actual independent static/browser review; it is not a claim of an automated third-party certification.
