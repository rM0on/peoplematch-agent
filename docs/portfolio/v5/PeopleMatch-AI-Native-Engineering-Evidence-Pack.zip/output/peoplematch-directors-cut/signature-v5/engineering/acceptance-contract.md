# Frozen acceptance contract · EDR-01

1. A completed persisted synthetic Explanation source with canonical bundle and structured brief yields one row per unique JD requirement, grouped must-have before nice-to-have, canonical persisted bundle order within each group. The existing bundle builder sorts by requirement ID; original JD wording order is not recoverable here.
2. Each row has canonical ID/text/priority, original diagnostic/evidence status, and only matching canonical single-requirement propositions. Multi-requirement recommendations are presented separately as aggregate, never as proof of an individual requirement. Candidate-material support is displayed only with a candidate-scoped historical source ID; current mutable candidate profile text cannot relabel old evidence.
3. Missing/partial/claim-only/not-assessed never becomes a statement that the candidate lacks a skill. The page says Unknown is an evidence state.
4. Missing, invalid, duplicated or mismatched source, candidate owner, fingerprints, proposition refs, or diagnostic coverage fails closed with a typed error; no partial trusted matrix.
5. Read-only GET API has a typed success envelope and safe 404/409 failures. It performs no write, rank mutation, Provider call or model retraining.
6. Recruiter View can open the workbench for the selected candidate; the page supports loading, invalid input, no source and API error states plus source drill-down.
7. Backend unit/API, frontend contract/component, adversarial input and relevant regression tests pass. A failed test may not be removed or weakened just to satisfy this criterion.
8. A real browser can operate the UI against a local synthetic API fixture and show actual source-labeled rows. This is labeled synthetic integration, not PostgreSQL readback.
9. The V5 Evidence Pack includes mission, execution commands, diff/review findings, test results, browser image, accepted limits and exact reproduction steps.
