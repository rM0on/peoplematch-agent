# Read-first context map

| Need | Canonical source |
|---|---|
| Repo boundaries | `AGENTS.md`, `README.md`, `docs/PRD.md`, `docs/architecture.md`, `docs/development-roadmap.md` |
| Historical requirement text and IDs | `backend/app/schemas/explanations.py` · `HistoricalJobEvidence.requirements` |
| Candidate requirement diagnostics | `backend/app/services/explanation/evidence/requirement_builder.py`, `contracts.py` |
| Persisted source/fingerprint/refs | `backend/app/repositories/recruiter_narrative_repository.py` |
| Canonical structured recruiter conclusions | `backend/app/services/explanation/presentation/structured_service.py`, `contracts_proposition_v1.py`, `backend/app/schemas/recruiter_proposition.py` |
| API convention | `backend/app/api/routes/recruiter_propositions.py`, `backend/app/api/dependencies.py`, `backend/app/api/router.py` |
| Frontend identity check and source labels | `frontend/src/lib/trusted-recruiter.ts`, `frontend/src/features/recruiter-view/recruiter-view-screen.tsx` |
| Frontend route convention | `frontend/node_modules/next/dist/docs/01-app/01-getting-started/03-layouts-and-pages.md`, `.../03-api-reference/03-file-conventions/page.md` (read before frontend work) |
| Synthetic test source | `backend/tests/narrative_v2_comparison_fixture.py`, `backend/tests/test_recruiter_proposition_runtime.py` |

Only task-relevant files are in the first-read set; the whole repository is not copied into a prompt.
