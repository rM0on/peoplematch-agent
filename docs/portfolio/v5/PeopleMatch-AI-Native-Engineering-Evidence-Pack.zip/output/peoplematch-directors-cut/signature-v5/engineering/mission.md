# Master Mission · Core Requirement Verification Workbench

Created before V5 product implementation, 2026-10-13.

## Objective and business context

Help a recruiter inspect *every* canonical JD core/nice requirement for one candidate against existing source-backed diagnostics. The view should answer: what is linked to candidate material, what is a claim only, what is unestablished, and what exact evidence/verification target can be opened next. It is human review support, not a new ranking or hiring decision.

## Codex execution space

- Read first: `engineering/context-map.md`, then referenced source/tests.
- In scope: additive backend response schema/service/route; typed frontend read-only page/API and link; focused tests; V5 evidence/docs.
- Out of scope: persistence migration, ranking rerun, new Provider calls, synthetic skills, modifying source facts to improve display.
- Frozen: Phase 4–11 contracts, MatchRun order/scores/fingerprint, Grounding and structured Proposition semantics/builders, frozen experiments.
- Reuse canonical persisted-source integrity checks and existing requirement/proposition builders. Do not create a parallel truth table.

## Test-first and tools

First add backend tests for full requirement coverage, source-backed refs, missing source, cross-candidate mismatch and duplicate/inconsistent records; observe implementation RED. Add frontend contract and state tests before implementing page. Use `pytest`, frontend `vitest`, `tsc`, `eslint`, `next build`, FastAPI TestClient and browser. Inspect diff and ensure frozen paths unchanged. Do not weaken an assertion for GREEN.

## Failure policy

Local presentation defects may be repaired in the additive projection or UI with regression tests. If canonical source data cannot support a requirement row, fail closed or mark not assessed; never infer a skill. If the design requires modifying ranking, Grounding, proposition semantics or historical data, stop that path and revisit the task decision.

## Handoff

Update `STATE.md`, `DECISIONS.md`, `HANDOFF.md`, `RESUME.md` with actual state, failures and next commands after each gate. Actual tool outputs go to `execution/`; no reconstructed chat is passed off as original conversation.
