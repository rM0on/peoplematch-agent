"""Isolated read-only acceptance checker; not used by PeopleMatch runtime.

This checks only the descriptor/citation closure and candidate-rank scope. The
existing Service, typed schema and trusted frontend own the full contract.
"""


class SourceClosureError(ValueError):
    pass


def audit_source_closure(payload: dict) -> int:
    prefix = f"candidate:{payload['result_rank']}:"
    descriptors = payload["source_descriptors"]
    refs = [item["evidence_ref"] for item in descriptors]
    if any(not ref.startswith(prefix) for ref in refs):
        raise SourceClosureError("foreign_candidate_ref")
    if len(refs) != len(set(refs)):
        raise SourceClosureError("duplicate_descriptor")

    propositions = [
        proposition
        for row in payload["requirements"]
        for proposition in row["propositions"]
    ] + list(payload["cross_requirement_propositions"])
    used = {
        ref
        for proposition in propositions
        if proposition["job_requirement_refs"]
        for ref in proposition["evidence_refs"]
        if ref.startswith("candidate:")
    }
    if any(not ref.startswith(prefix) for ref in used):
        raise SourceClosureError("foreign_candidate_ref")
    delivered = set(refs)
    if used - delivered:
        raise SourceClosureError("missing_descriptor")
    if delivered - used:
        raise SourceClosureError("uncited_descriptor")
    return len(delivered)
