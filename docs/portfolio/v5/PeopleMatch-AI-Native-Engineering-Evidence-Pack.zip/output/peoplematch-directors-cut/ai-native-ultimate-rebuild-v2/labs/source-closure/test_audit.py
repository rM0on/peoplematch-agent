"""Independent negative-path acceptance over an actual V5 Service payload."""

from __future__ import annotations

import asyncio
from copy import deepcopy

import pytest

from narrative_v2_comparison_fixture import build_comparison_group
from test_recruiter_proposition_runtime import _SourceRepository, _source

from app.services.explanation.presentation.structured_service import RecruiterPropositionService
from app.services.requirement_review.service import RequirementReviewService

from audit import SourceClosureError, audit_source_closure


@pytest.fixture
def payload():
    group = build_comparison_group(1)
    repo = _SourceRepository(_source(group))
    value = asyncio.run(RequirementReviewService(repo, RecruiterPropositionService(repo)).get(42))
    return value.model_dump(mode="json")


def test_service_payload_has_exact_source_closure(payload):
    assert audit_source_closure(payload) == len(payload["source_descriptors"])


def test_rejects_uncited_descriptor(payload):
    mutant = deepcopy(payload)
    mutant["source_descriptors"].append({
        "evidence_ref": "candidate:1:project:unused_999",
        "source_kind": "historical_project",
        "description": "controlled adversarial descriptor",
    })
    with pytest.raises(SourceClosureError, match="uncited_descriptor"):
        audit_source_closure(mutant)


def test_rejects_missing_cited_descriptor(payload):
    mutant = deepcopy(payload)
    assert mutant["source_descriptors"]
    mutant["source_descriptors"].pop()
    with pytest.raises(SourceClosureError, match="missing_descriptor"):
        audit_source_closure(mutant)


def test_rejects_duplicate_descriptor(payload):
    mutant = deepcopy(payload)
    mutant["source_descriptors"].append(deepcopy(mutant["source_descriptors"][0]))
    with pytest.raises(SourceClosureError, match="duplicate_descriptor"):
        audit_source_closure(mutant)


def test_rejects_foreign_candidate_ref(payload):
    mutant = deepcopy(payload)
    target = mutant["source_descriptors"][0]
    target["evidence_ref"] = target["evidence_ref"].replace("candidate:1:", "candidate:2:")
    with pytest.raises(SourceClosureError, match="foreign_candidate_ref"):
        audit_source_closure(mutant)
